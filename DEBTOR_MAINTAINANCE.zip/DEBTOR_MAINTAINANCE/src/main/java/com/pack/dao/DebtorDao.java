package com.pack.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.pack.model.Debtor;
import com.pack.model.Bank;

 
public class DebtorDao {
 
public   int save(Debtor u){
	int status=0;
	try{
		Connection con=MySqlConn.getCon();
		PreparedStatement ps=con.prepareStatement("insert into debtor(dname,id,address,address2,address3,fax,phone,email)  values(?,?,?,?,?,?,?,?)");
	 
		ps.setString(1,u.getDname());
	 	ps.setInt(2,u.getId());
		ps.setString(3,u.getAddress());
		ps.setString(4,u.getAddress2());
		ps.setString(5,u.getAddress3());
		ps.setString(6,u.getFax());
		ps.setString(7,u.getPhone());
		ps.setString(8,u.getEmail());
		status=ps.executeUpdate();
	}catch(Exception e){System.out.println(e);}
	return status;
	
	
}
public   int save(Bank b){
	int status=0;
	try{
		Connection con=MySqlConn.getCon();
		PreparedStatement ps=con.prepareStatement("insert into Bank(name,accnum,branch,address,id)  values(?,?,?,?,?)");
	 
		ps.setString(1,b.getName());
	 	ps.setString(2,b.getAccnum());
	 	ps.setString(3,b.getBranch());
		ps.setString(4,b.getAddress());
		ps.setString(5,b.getId());
		
		
		
		status=ps.executeUpdate();
	}catch(Exception e){System.out.println(e);}
	return status;
}
	


  public int update(Debtor u){ int status=0; try{ Connection
  con=MySqlConn.getCon();
  
  PreparedStatement ps=con.prepareStatement("update debtor set dname=?,id=?,address=?,address2=?, address3=?, fax=?, phone=? where id=?" ); 
  System.out.println(" "+u.getDname()+" "+u.getId()+" "+u.getAddress()+" "+u.getAddress2()+" "+u.getAddress3()+" "+u.getFax()+" "+u.getPhone()+" "+u.getEmail());
	
	ps.setString(1, u.getDname());
	ps.setInt(2, u.getId());
	ps.setString(3, u.getAddress());
	ps.setString(4, u.getAddress2());
	ps.setString(5, u.getAddress3());
	ps.setString(6, u.getFax());
	ps.setString(7, u.getPhone());
	ps.setString(8, u.getEmail());
  
  status=ps.executeUpdate(); 
  }catch(Exception e){System.out.println(e);} 
  return status; 
  } 
  
	/*
	 * public int delete(Employee u){ int status=0; try{ Connection
	 * con=MySqlConn.getCon(); PreparedStatement
	 * ps=con.prepareStatement("delete from register where id=?");
	 * ps.setInt(1,u.getId()); status=ps.executeUpdate(); }catch(Exception
	 * e){System.out.println(e);}
	 * 
	 * return status; }
	 */
 
public   List<Debtor> getAllRecords(){
	List<Debtor> list=new ArrayList<Debtor>();
	
	try{
		Connection con=MySqlConn.getCon();
		PreparedStatement ps=con.prepareStatement("select * from debtor");
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			Debtor u=new Debtor();
			u.setDname(rs.getString("dname"));
			u.setId(rs.getInt("id"));
			u.setAddress(rs.getString("address"));
			u.setAddress2(rs.getString("address2"));
			u.setAddress3(rs.getString("address3"));
			u.setFax(rs.getString("fax"));
			u.setPhone(rs.getString("phone"));
		 	u.setEmail(rs.getString("email"));
			
			list.add(u);
		}
	}catch(Exception e){System.out.println(e);}
	return list;
}
public   Debtor getRecordById(int id){
	Debtor u=null;
	try{
		Connection con=MySqlConn.getCon();
		PreparedStatement ps=con.prepareStatement("select * from debtor where id=?");
		ps.setInt(1, id);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			u=new Debtor();
			u.setDname(rs.getString("dname"));
			u.setId(rs.getInt("id"));
			u.setAddress(rs.getString("address"));
			u.setAddress2(rs.getString("address2"));
			u.setAddress3(rs.getString("address3"));
			u.setFax(rs.getString("fax"));
			u.setPhone(rs.getString("phone"));
		 	u.setEmail(rs.getString("email"));
			
		}
	}catch(Exception e){System.out.println(e);}
	return u;
}
public   List<Bank> getAllRecords1(){
	List<Bank> list=new ArrayList<Bank>();
	
	try{
		Connection con=MySqlConn.getCon();
		PreparedStatement ps=con.prepareStatement("select * from Bank");
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			Bank b=new Bank();

			b.setName(rs.getString("Name"));
		 	b.setAccnum(rs.getString("Accnum"));
		 	b.setBranch(rs.getString("Branch"));
			b.setAddress(rs.getString("Address"));
			b.setId(rs.getString("Id"));
			list.add(b);
		}
	}catch(Exception e){System.out.println(e);}
	return list;
}
/**
 * @param id
 * @return
 */
/*
 * public List<Bank> getRecordById1(int id){ Bank b=null; List<Bank> list=new
 * ArrayList<Bank>();
 * 
 * try{ Connection con=MySqlConn.getCon(); PreparedStatement
 * ps=con.prepareStatement("select * from Bank where id=?"); ResultSet
 * rs=ps.executeQuery(); ps.setInt(1,id); while(rs.next()){ b=new Bank();
 * 
 * b.setName(rs.getString("Name")); b.setAccnum(rs.getString("Accnum"));
 * b.setBranch(rs.getString("Branch")); b.setAddress(rs.getString("Address"));
 * b.setId(rs.getString("Id")); list.add(b); } }catch(Exception
 * e){System.out.println(e);} return list; }
 */
}
